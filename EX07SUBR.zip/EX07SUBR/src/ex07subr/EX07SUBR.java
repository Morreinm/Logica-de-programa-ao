package ex07subr;
import java.util.Scanner;

public class EX07SUBR {

    static boolean primoounao(int n) {

        if (n <= 1) {
            return false;
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;

            }

        }
        return true;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("digite um numero");
        int n = teclado.nextInt();

        if (primoounao(n) == true) {
            System.out.println("é primo");

        } else {
            System.out.println("N é primo");
        }

    }

}
