package ex03.qtdpalavras;

import java.util.Scanner;

public class EX03Qtdpalavras {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        String texto;
        System.out.println("diga algo ai");
        texto = teclado.nextLine();
        
        String[] palavra = texto.split(" ");
        
        System.out.println(palavra.length);

    }

}
