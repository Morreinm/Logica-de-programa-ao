package ler_2_numeros_apresentar_maior2;

import java.util.Scanner;

public class Ler_2_numeros_apresentar_maior2 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int n1;
        int n2;
        int maior;
        System.out.println("Insira os numeros");
        n1 = teclado.nextInt();
        n2 = teclado.nextInt();

        if (n1 > n2) {
            System.out.println("o numero" + n1 +  "é maior que o" + n2
          
            );
    } else {
            System.out.println("o numero" + n2 +  "é maior que o numero" + n2
        
    

);
        }
    }

}
