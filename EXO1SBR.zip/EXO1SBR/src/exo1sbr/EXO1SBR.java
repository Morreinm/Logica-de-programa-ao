package exo1sbr;

public class EXO1SBR {

    static void contador(int n) {
 
        if (n > 100) {
            return;
        }

        System.out.println(n);
        contador(n +1);
        

       
        }


    public static void main(String[] args) {
        
        contador(0);

    }

}
