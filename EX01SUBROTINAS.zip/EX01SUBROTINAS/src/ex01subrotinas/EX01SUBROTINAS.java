package ex01subrotinas;

import java.util.Scanner;

public class EX01SUBROTINAS {

    static int multiplicacao(int n1, int n2) {

        int resp;
        resp = n1 * n2;
        return resp;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n11, n22;
        int total;
        System.out.println("digite 2 numeros:");
        n11 = teclado.nextInt();
        System.out.println("digite o segundo numero:");
        n22 = teclado.nextInt();
        total = multiplicacao(n11, n22);
        System.out.println(total);

    }

}
