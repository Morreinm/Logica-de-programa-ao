package ex08subr;

import java.util.Scanner;

public class EX08SUBR {

    static void maioroumenor(int[] numeros) {
        int maior = numeros[0];
        int menor = numeros[0];

        for (int i = 1; i < 5; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
        }

        System.out.println("O maior número é: " + maior);
        System.out.println("O menor número é: " + menor);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] valores = new int[5];

        System.out.println("Digite 5 números inteiros:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            valores[i] = teclado.nextInt();
        }

        maioroumenor(valores);
       
    }
}
