package exe1_conersao_farenheit_graus;

import java.util.Scanner;

public class Exe1_conersao_farenheit_graus {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        double f, c;
        System.out.println("digite os farenheits");
        f = teclado.nextDouble();
        c = (9 * f + 160) / 5;
        System.out.println("os graus sao:" + c);

    }

}
