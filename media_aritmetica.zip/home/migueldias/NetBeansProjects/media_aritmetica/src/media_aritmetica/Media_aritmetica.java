
package media_aritmetica;

import java.util.Scanner;

public class Media_aritmetica {

  
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double n1;
        double n2;
        double n3;
        double med;
        
        System.out.println("digite as 3 notas");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        n3 = teclado.nextDouble();
        
        med = (n1+n2+n3)/3;
        
        if(med > 6.0){
            System.out.println("Aprovado");
        } else{
            System.out.println("Reprovado");}
        
        
        
    }
    
}
