package test.codigo;

import java.util.Scanner;

public class TestCodigo {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int cont = 0, num, cont0=0, contneg=0, contpstv=0;

        while (cont < 10) {
            System.out.println("diga um numero");
            num = teclado.nextInt();
            cont++;
            if (num < 0){
                contneg++;
            }
            if(num > 0){contpstv++;}
            if(num == 0){cont0++;}
           
            
        }
 System.out.println(cont0 + " zeros " + contneg + " negativos  " + contpstv + " positivos");
    }

}
