package matriz02;

import java.util.Scanner;

public class Matriz02 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int numeros[][] = new int[3][3];
        int menornum = 0;
        for (int linhas = 0; linhas < 3; linhas++) {
            for (int colunas = 0; colunas < 3; colunas++) {
                System.out.println("digite um numero");
                numeros[linhas][colunas] = kb.nextInt();

            }

        }
        menornum = numeros[0][0];
        for (int menornumerol = 0; menornumerol < 3; menornumerol++) {
            for (int menornumeroc = 0; menornumeroc < 3; menornumeroc++) {
                if (menornum > numeros[menornumerol][menornumeroc]) {
                    menornum = numeros[menornumerol][menornumeroc];
                }

            }

        }
        System.out.println("menor num:" + menornum);

    }

}
