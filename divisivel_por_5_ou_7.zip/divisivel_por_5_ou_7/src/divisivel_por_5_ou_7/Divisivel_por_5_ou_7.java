package divisivel_por_5_ou_7;

import java.util.Scanner;

public class Divisivel_por_5_ou_7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int n;
        
       
        System.out.println("digite um numero");
        n = teclado.nextInt();
        if (n % 5 == 0 ||  n % 7 == 0){
            System.out.println("numero divisivel por 5 ou 7");
            
        }else {
            System.out.println("numero indivisivel por 5 ou 7");}
        
    }

}
