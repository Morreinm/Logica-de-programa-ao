package ler_3_numeros_apresentar_ordem_crescente2;

import java.util.Scanner;

public class Ler_3_numeros_apresentar_ordem_crescente2 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int a = teclado.nextInt();
        System.out.print("Digite o segundo número: ");
        int b = teclado.nextInt();
        System.out.print("Digite o terceiro número: ");
        int c = teclado.nextInt();

        System.out.println("\nNúmeros em ordem crescente:");

        // Testa cada uma das 6 combinações possíveis
        if (a <= b && b <= c) {
            System.out.println(a + " " + b + " " + c);
        } else if (a <= c && c <= b) {
            System.out.println(a + " " + c + " " + b);
        } else if (b <= a && a <= c) {
            System.out.println(b + " " + a + " " + c);
        } else if (b <= c && c <= a) {
            System.out.println(b + " " + c + " " + a);
        } else if (c <= a && a <= b) {
            System.out.println(c + " " + a + " " + b);
        } else {
            System.out.println(c + " " + b + " " + a);
        }
    }
}
