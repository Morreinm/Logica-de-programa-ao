package classificaçao_idade;

import java.util.Scanner;

public class Classificaçao_idade {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int idade;
        String nome;
        String classe;

        System.out.println("digite seu nome");
        nome = teclado.next();

        System.out.println("digite sua idade");
        idade = teclado.nextInt();

        if (idade >= 5 && idade <= 7) {
            classe = "infantil A";
            System.out.println("Sua classe é: " + classe);
        } else if (idade >= 8 && idade <= 10) {
            classe = "infantil B";
            System.out.println("sua classe é: " + classe);
        } else if (idade >= 11 && idade <= 13) {
            classe = "Juvenil A";
            System.out.println("sua classe é: " + classe);
        }

    }
}
