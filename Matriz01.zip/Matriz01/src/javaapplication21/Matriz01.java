package javaapplication21;

import java.util.Scanner;

public class Matriz01 {

    public static void main(String[] args) {

        int numero[][] = new int[5][4];
        Scanner miguel = new Scanner(System.in);

        int numeros[][] = new int[5][5];
        for (int linhas = 0; linhas < 5; linhas++) {
            for (int colunas = 0; colunas < 5; colunas++) {

                System.out.println("digite um numero");
                numeros[linhas][colunas] = miguel.nextInt();

            }

        }
        for (int mostrarlinha = 0; mostrarlinha < 5; mostrarlinha++) {
            for (int mostrarcoluna = 0; mostrarcoluna < 5; mostrarcoluna++) {
                System.out.println(numeros[mostrarlinha][mostrarcoluna]);

            }

        }

    }

}

