package multiplo_ou_nao;

import java.util.Scanner;

public class Multiplo_ou_nao {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int n1;
        int n2;

        System.out.println("digite 2 numeros");
        n1 = teclado.nextInt();
        n2 = teclado.nextInt();

        if (n1 % n2 == 0) {
            System.out.println("o numero " + n1 + " e multiplo de " + n2);
        } else {
            System.out.println("o numero " + n1 + " nao e multiplo de " + n2);
        }

    }

}
