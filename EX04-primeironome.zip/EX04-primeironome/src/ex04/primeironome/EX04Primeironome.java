package ex04.primeironome;
import java.util.Scanner;

public class EX04Primeironome {

   
    public static void main(String[] args) {
          Scanner teclado = new Scanner(System.in);

        String texto;
        System.out.println("diga algo ai");
        texto = teclado.nextLine();
        
        String[] palavra = texto.split(" ");
        
        System.out.println(palavra[0]);
        
    
    }
    
    
}
