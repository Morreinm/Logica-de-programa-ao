package aumento_salarial;

import java.util.Scanner;

public class Aumento_salarial {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int codigo;
        double salarioAntigo, novoSalario, diferenca, percentual;

        System.out.println("Digite o salário atual do funcionário:");
        salarioAntigo = teclado.nextDouble();

        System.out.println("Digite o código do cargo:");
        codigo = teclado.nextInt();

        if (codigo == 101) {
            percentual = 0.10;
        } else if (codigo == 102) {
            percentual = 0.20;
        } else if (codigo == 103) {
            percentual = 0.30;
        } else {
            percentual = 0.40;
        }

        diferenca = salarioAntigo * percentual;
        novoSalario = salarioAntigo + diferenca;

        System.out.println("Salário antigo: R$ " + salarioAntigo);
        System.out.println("Novo salário: R$ " + novoSalario);
        System.out.println("Diferença: R$ " + diferenca);
    }
}
