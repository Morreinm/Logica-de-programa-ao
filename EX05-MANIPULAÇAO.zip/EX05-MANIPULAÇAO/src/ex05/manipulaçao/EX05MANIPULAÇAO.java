package ex05.manipulaçao;

import java.util.Scanner;

public class EX05MANIPULAÇAO {

    public static void main(String[] args) {
        String data;
        Scanner teclado = new Scanner(System.in);
        System.out.println("diga o ano nesses formatos: dd/mm/aaaa ou dd/mm/aa");
        data = teclado.nextLine();
        String ano[] = data.split("/");
        int resp = Integer.parseInt(ano[2]);
        if (resp == 99) {
            System.out.println("00");
        } else {
            resp++;
            System.out.println(resp);
        }

    }

}
