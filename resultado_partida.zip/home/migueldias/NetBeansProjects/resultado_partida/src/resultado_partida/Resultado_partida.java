package resultado_partida;

import java.util.Scanner;

public class Resultado_partida {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String time1, time2;
        int golsTime1, golsTime2;

        System.out.println("Digite o nome do primeiro time:");
        time1 = teclado.next();

        System.out.println("Digite os gols do primeiro time:");
        golsTime1 = teclado.nextInt();

        System.out.println("Digite o nome do segundo time:");
        time2 = teclado.next();

        System.out.println("Digite os gols do segundo time:");
        golsTime2 = teclado.nextInt();

        if (golsTime1 > golsTime2) {
            System.out.println("Vencedor: " + time1);
        } else if (golsTime2 > golsTime1) {
            System.out.println("Vencedor: " + time2);
        } else {
            System.out.println("EMPATE");
        }
    }
}
