package exsbr03_segundos;

public class Exsbr03_segundos {
    static void converter(int s){
    int horas = s / 3600;
    s = s % 3600;
    int minutos = s / 60;
    s = s % 60;
        System.out.println("Horas: " + horas);
        System.out.println("Minutos: " + minutos);
        System.out.println("Segundos: " + s);
    }

    public static void main(String[] args) {
        converter(3600);
        
        
    }
    
}
