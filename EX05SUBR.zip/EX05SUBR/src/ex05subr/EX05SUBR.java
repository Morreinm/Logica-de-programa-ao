package ex05subr;
import java.util.Scanner;
public class EX05SUBR {

    static double media(double N1, double N2, double N3, String letra) {
        double medias;
        if (letra.equalsIgnoreCase("A")) {
            medias = (N1 + N2 + N3) / 3;
            System.out.println("A media aritmetica é de: " + medias);

        } else {
            medias = (N1 * 5 + N2 * 3 + N3 * 2) / 10.0;
            System.out.println("A media ponderada é de: " + medias);

        }
        return medias;
    }

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String letra;
        double N1,N2,N3;
        System.out.println("digite uma letra A/B A=ARITMETICA --- B=PONDERADA: ");
        letra = teclado.next();
        System.out.println("digite as 3 notas");
        N1 = teclado.nextDouble();
        N2 = teclado.nextDouble();
        N3 = teclado.nextDouble();
        System.out.println(media(N1, N2, N3, letra));
    }

}
