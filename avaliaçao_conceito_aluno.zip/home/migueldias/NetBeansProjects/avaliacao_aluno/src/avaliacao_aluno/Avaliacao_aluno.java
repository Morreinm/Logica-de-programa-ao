package avaliacao_aluno;

import java.util.Scanner;

public class Avaliacao_aluno {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numeroAluno;
        double nota1, nota2, nota3, me, ma;
        String conceito, status;

        System.out.println("Digite o número de identificação do aluno:");
        numeroAluno = teclado.nextInt();

        System.out.println("Digite a primeira nota:");
        nota1 = teclado.nextDouble();

        System.out.println("Digite a segunda nota:");
        nota2 = teclado.nextDouble();

        System.out.println("Digite a terceira nota:");
        nota3 = teclado.nextDouble();

        System.out.println("Digite a média dos exercícios:");
        me = teclado.nextDouble();

        ma = (nota1 + (nota2 * 2) + (nota3 * 3) + me) / 7;

        if (ma >= 9.0) {
            conceito = "A";
            status = "APROVADO";
        } else if (ma >= 7.5) {
            conceito = "B";
            status = "APROVADO";
        } else if (ma >= 6.0) {
            conceito = "C";
            status = "APROVADO";
        } else if (ma >= 4.0) {
            conceito = "D";
            status = "REPROVADO";
        } else {
            conceito = "E";
            status = "REPROVADO";
        }

        System.out.println("Número do aluno: " + numeroAluno);
        System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
        System.out.println("Média dos exercícios: " + me);
        System.out.println("Média de aproveitamento: " + ma);
        System.out.println("Conceito: " + conceito);
        System.out.println("Situação: " + status);
    }
}
