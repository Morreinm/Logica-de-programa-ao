
package quantidadechar;
import java.util.Scanner;


public class QuantidadeChar {

   
    public static void main(String[] args) {
        int tam;
        String texto;
        Scanner kb = new Scanner(System.in);
        System.out.println("fale algo ai");
        texto = kb.nextLine();
        tam = texto.length();
        System.out.println(tam);
        
        
    }
    
}
