package ex06subr;

import java.util.Scanner;

public class EX06SUBR {

    static double jogo(double HRI, double MNI, double HRF, double MNF) {
       char nada = ' ';
        MNI += HRI * 60;
        MNF += HRF * 60;
        double tempototal;
        if (MNI >= MNF) {
            System.out.println("PASSOU UM DIA");

            tempototal = (MNF + 1440) - MNI;
            System.out.println("DUROU: " + tempototal + " MINUTOS");
        } else {
            System.out.println("Nao passou um dia");
            tempototal = MNF - MNI;
            System.out.println("DUROU: " + tempototal + " MINUTOS");
        }
        return  tempototal;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double HRI, MNI, HRF, MNF;
        System.out.println("diga as horas iniciais e os minutos iniciais:");
        HRI = teclado.nextDouble();
        MNI = teclado.nextDouble();
        System.out.println("agora diga as horas finais e os minutos finais");
        HRF = teclado.nextDouble();
        MNF = teclado.nextDouble();
        jogo(HRI, MNI, HRF, MNF);
    }

}
