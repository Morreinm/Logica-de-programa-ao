package ex06.manipulaçao;
import java.util.Scanner;

public class EX06MANIPULAÇAO {

   
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome, nomeFinal;
        System.out.println("digite o nome de  uma pessoa");
       nome = teclado.nextLine();
    String separado[] =  nome.split(" ");
    nomeFinal = separado[separado.length-1] + ", ";
        for (int i = 0; i <= separado.length-2; i++) {
          nomeFinal = nomeFinal + separado[i] + " ";
            
            
        }
            
            System.out.println(nomeFinal);
            
        
       
    }
    
}
