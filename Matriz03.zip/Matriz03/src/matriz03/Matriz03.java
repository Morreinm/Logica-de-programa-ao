package matriz03;

import java.util.Scanner;

public class Matriz03 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        int maiornum = 0;
        int numerosmult2 = 1;
        int numeros[][] = new int[2][2];
        int numerosmult[][] = new int[2][2];

        for (int linhasm = 0; linhasm < 2; linhasm++) {
            for (int colunasm = 0; colunasm < 2; colunasm++) {
                System.out.println("diga um numero");
                numeros[linhasm][colunasm] = kb.nextInt();

            }

        }
        maiornum = numeros[0][0];
        for (int testarml = 0; testarml < 2; testarml++) {
            for (int testarmc = 0; testarmc < 2; testarmc++) {
                if (maiornum < numeros[testarml][testarmc]) {
                    maiornum = numeros[testarml][testarmc];

                }

            }
        }
        System.out.println("maior num:" + maiornum);

        for (int multl = 0; multl < 2; multl++) {
            for (int multc = 0; multc < 2; multc++) {
                numerosmult[multl][multc] = maiornum * numeros[multl][multc];

            }

        }
        for (int mostrarmultl = 0; mostrarmultl < 2; mostrarmultl++) {
            for (int mostrarmultc = 0; mostrarmultc < 2; mostrarmultc++) {
                System.out.println("multiplicaçao:" + numerosmult[mostrarmultl][mostrarmultc]);
                
            }
            
        }

    }

}
