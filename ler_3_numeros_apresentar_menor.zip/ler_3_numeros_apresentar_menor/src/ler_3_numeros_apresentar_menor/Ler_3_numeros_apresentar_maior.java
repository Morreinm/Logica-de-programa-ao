package ler_3_numeros_apresentar_maior;

import java.util.Scanner;

public class Ler_3_numeros_apresentar_maior {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int n1;
        int n2;
        int n3;

        System.out.println("Diga 3 numeros");

        n1 = teclado.nextInt();
        n2 = teclado.nextInt();
        n3 = teclado.nextInt();

        if (n1 > n2) {
            if (n2 > n3) {
                System.out.println("o menor numero e " + n3);

            } else {
                System.out.println("o menor numero e " + n2);
            }
        } else if (n3 > n1) {
            System.out.println("o menor numero e " + n1);
        } else {
            System.out.println("o menor numero e " + n3);
        }

    }

}