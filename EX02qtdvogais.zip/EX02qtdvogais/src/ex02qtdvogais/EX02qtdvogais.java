
package ex02qtdvogais;
import java.util.Scanner;

public class EX02qtdvogais {

    public static void main(String[] args) {
                int vogais = 0;
        char S;
        String texto;
        Scanner teclado = new Scanner(System.in);
        System.out.println("diga algo ai");
        texto = teclado.nextLine().toLowerCase();
        for (int i = 0; i < texto.length(); i++) {
            S = texto.charAt(i);
            if (S == 'a' || S == 'e' || S == 'i' || S == 'o' || S == 'u') {
                vogais++;
            }

        }
        System.out.println("Quantidades de vogais: " + vogais);
    }
    
}
