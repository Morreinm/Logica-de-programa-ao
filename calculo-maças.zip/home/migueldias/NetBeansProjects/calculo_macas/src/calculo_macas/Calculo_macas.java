package calculo_macas;

import java.util.Scanner;

public class Calculo_macas {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int quantidade;
        double custoTotal;

        System.out.println("Digite o número de maçãs compradas:");
        quantidade = teclado.nextInt();

        if (quantidade < 12) {
            custoTotal = quantidade * 1.30;
        } else {
            custoTotal = quantidade * 1.00;
        }

        System.out.println("Custo total da compra: R$ " + custoTotal);
    }
}
