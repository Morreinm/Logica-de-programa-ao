package ex02subrotinas;
import java.util.Scanner;

public class EX02SUBROTINAS {
    static int somaentre(int n1, int n2){
    int acum = 0;
        for (int i = n1 + 1; i < n2 ; i++) {
            acum = acum + i;
            
        }
        return acum;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n11, n22;
        int resp;
        
        System.out.println("diga 2 numeros:");
        n11 = teclado.nextInt();
        n22 = teclado.nextInt();
        
        
        resp = somaentre(n11, n22);
        System.out.println(resp);
        
                
    }

}
