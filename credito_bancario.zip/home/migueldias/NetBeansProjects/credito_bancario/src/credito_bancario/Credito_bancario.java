package credito_bancario;

import java.util.Scanner;

public class Credito_bancario {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double saldoMedio, valorCredito;

        System.out.println("Digite o saldo médio do cliente:");
        saldoMedio = teclado.nextDouble();

        if (saldoMedio >= 0 && saldoMedio <= 200) {
            valorCredito = 0;
        } else if (saldoMedio >= 201 && saldoMedio <= 400) {
            valorCredito = saldoMedio * 0.20;
        } else if (saldoMedio >= 401 && saldoMedio <= 600) {
            valorCredito = saldoMedio * 0.30;
        } else if (saldoMedio >= 601) {
            valorCredito = saldoMedio * 0.40;
        } else {
            valorCredito = 0;
            System.out.println("Saldo inválido!");
        }

        System.out.println("Saldo Médio: R$ " + saldoMedio);
        System.out.println("Valor do Crédito: R$ " + valorCredito);
    }
}
