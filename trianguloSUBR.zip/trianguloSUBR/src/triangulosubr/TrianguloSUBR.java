package triangulosubr;


public class TrianguloSUBR {
    static String tritest(int l1, int l2, int l3) {

        String resp = "";

        if (l1 + l2 > l3 && l2 + l3 > l1 && l1 + l3 > l2) {

            if (l1 == l2 && l2 == l3) {
                resp = "Equilatero";
                System.out.println(resp);

            } else if (l1 == l2 || l2 == l3) {
                resp = "Isoceles";
                System.out.println(resp);

            } else {
                resp = "escaleno";
                System.out.println(resp);
            }

        } else {
            resp = "NAO É UM É TRIANGULO";
            System.out.println(resp);
                    
        }

        return resp;
    }

    public static void main(String[] args) {
        
        tritest(3, 3, 3 );
      
    }
    
}
