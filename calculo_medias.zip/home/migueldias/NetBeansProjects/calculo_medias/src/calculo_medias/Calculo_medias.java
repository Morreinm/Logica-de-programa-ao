package calculo_medias;

import java.util.Scanner;

public class Calculo_medias {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double nota1, nota2, nota3, mediaFinal;
        int opcao;

        System.out.println("Digite a primeira nota:");
        nota1 = teclado.nextDouble();

        System.out.println("Digite a segunda nota:");
        nota2 = teclado.nextDouble();

        System.out.println("Digite a terceira nota:");
        nota3 = teclado.nextDouble();

        System.out.println("Escolha o tipo de média:");
        System.out.println("1 - Aritmética");
        System.out.println("2 - Ponderada (pesos 3, 3, 4)");
        opcao = teclado.nextInt();

        if (opcao == 1) {
            mediaFinal = (nota1 + nota2 + nota3) / 3;
            System.out.println("A média aritmética é: " + mediaFinal);
        } else if (opcao == 2) {
            mediaFinal = ((nota1 * 3) + (nota2 * 3) + (nota3 * 4)) / 10;
            System.out.println("A média ponderada é: " + mediaFinal);
        } else {
            System.out.println("Opção inválida! Escolha 1 ou 2.");
        }
    }
}
